package com.example.visha.tastytreat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.visha.tastytreat.R;
import com.example.visha.tastytreat.model.Recipe;
import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

public class RecipeAdapter extends Adapter<RecipeAdapter.RecipeViewHolder> {

    private List<Recipe> recipeList;
    private CardClickListener cardClickListener;

    public interface CardClickListener {

        void onClick (int position);

    }

    public RecipeAdapter(List<Recipe> recipeList, CardClickListener cardClickListener) {
        this.recipeList = recipeList;
        this.cardClickListener = cardClickListener;
    }

    @Override
    public RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recipe_home, parent, false);
        return new RecipeViewHolder(view);

    }

    @Override
    public void onBindViewHolder(RecipeViewHolder holder, int position) {

        if (!recipeList.get(position).getImageURL().equals(""))
            Picasso.get()
                    .load(recipeList.get(position).getImageURL())
                    .placeholder(R.drawable.home_placeholder_medium)
                    .into(holder.recipeImage);
        else
            holder.recipeImage.setImageResource(R.drawable.home_placeholder_medium);

        holder.recipeTv.setText(recipeList.get(position).getName());
        holder.noOfServings.setText(recipeList.get(position).getServings());
        holder.noOfIngredients.setText(String.valueOf(recipeList.get(position).getIngredientsList().size()));
        holder.noOfSteps.setText(String.valueOf(recipeList.get(position).getStepsList().size()));

    }

    @Override
    public int getItemCount() {
        return recipeList.size();
    }

    public class RecipeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private boolean isExpanded;

        ImageView recipeImage;
        TextView recipeTv;

        TextView noOfServings;
        TextView noOfIngredients;
        TextView noOfSteps;

        RecyclerView ingredientsDetailRv;

        View buttonToExpand;
        View buttonIcon;

        public RecipeViewHolder(View itemView) {
            super(itemView);

            recipeImage = itemView.findViewById(R.id.recipe_image);
            recipeTv = itemView.findViewById(R.id.recipe_tv);

            noOfServings = itemView.findViewById(R.id.serving_quantity_tv);
            noOfIngredients = itemView.findViewById(R.id.ingredient_quantity_tv);
            noOfSteps = itemView.findViewById(R.id.step_quantity_tv);

            ingredientsDetailRv = itemView.findViewById(R.id.ingredients_detail_rv);
            IngredientAdapter ingredientAdapter = new IngredientAdapter(recipeList.get(0).getIngredientsList());
            ingredientsDetailRv.setLayoutManager(new LinearLayoutManager(itemView.getContext()));
            ingredientsDetailRv.setAdapter(ingredientAdapter);

            buttonToExpand = itemView.findViewById(R.id.recipe_expand_bt);
            buttonIcon = itemView.findViewById(R.id.button_ic);

            itemView.setOnClickListener(this);
            ingredientsDetailRv.setOnClickListener(this);

            buttonToExpand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (!isExpanded) {

                        ingredientsDetailRv.setVisibility(View.VISIBLE);
                        buttonIcon.setBackgroundResource(R.drawable.home_ic_up_24dp);
                        isExpanded = true;

                    } else {

                        ingredientsDetailRv.setVisibility(View.GONE);
                        buttonIcon.setBackgroundResource(R.drawable.home_ic_down_24dp);
                        isExpanded = false;

                    }
                }
            });
        }

        @Override
        public void onClick(View v) {
            cardClickListener.onClick(getAdapterPosition());
        }
    }
}
