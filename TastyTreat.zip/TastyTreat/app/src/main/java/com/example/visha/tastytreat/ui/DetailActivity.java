package com.example.visha.tastytreat.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.visha.tastytreat.R;
import com.example.visha.tastytreat.view.BottomSheetFragment;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.visha.tastytreat.ui.HomeActivity.INTENT_EXTRA_POSITION;
import static com.example.visha.tastytreat.ui.HomeActivity.recipeList;

public class DetailActivity extends AppCompatActivity {

    private static final String TAG = DetailActivity.class.getSimpleName();

    private int position;

    private BottomAppBar bottomAppBar;
    private BottomSheetFragment bottomSheetFragment;

    private void populateUI () {

        getSupportActionBar().setTitle(recipeList.get(position).getName());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setElevation(0);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        position = getIntent().getIntExtra(INTENT_EXTRA_POSITION, -1);

        if (position != -1)
            populateUI();

        bottomAppBar = findViewById(R.id.bottom_bar);
        bottomAppBar.inflateMenu(R.menu.home_menu_item);
        bottomAppBar.getMenu().findItem(R.id.item_back).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if (item.getItemId() == R.id.item_back) {

                    Toast.makeText(DetailActivity.this, "Back Pressed!", Toast.LENGTH_SHORT).show();
                    return true;

                } else return false;

            }
        });
        bottomAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bottomSheetFragment = new BottomSheetFragment(recipeList.get(position).getName());
                bottomSheetFragment.show(getSupportFragmentManager(), bottomSheetFragment.getTag());

            }
        });
    }
}
