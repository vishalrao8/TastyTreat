package com.example.visha.tastytreat.view;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.visha.tastytreat.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.navigation.NavigationView;

public class BottomSheetFragment extends BottomSheetDialogFragment {

    private TextView recipeNameTv;
    private String recipeName;

    public BottomSheetFragment(String recipeName) {
        this.recipeName = recipeName;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_bottomsheet, container, false);

        NavigationView navigationView = rootView.findViewById(R.id.navigation_view);
        recipeNameTv = navigationView.getHeaderView(0).findViewById(R.id.navigation_header_sub_tv);
        recipeNameTv.setText(recipeName);

        return rootView;

    }
}
